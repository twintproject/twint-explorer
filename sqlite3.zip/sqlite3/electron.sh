npm install \
--build-from-source \
--runtime=electron --target=1.7.6 \
--dist-url=https://atom.io/download/electron
